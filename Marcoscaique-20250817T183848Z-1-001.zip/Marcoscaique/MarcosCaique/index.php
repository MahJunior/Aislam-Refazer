<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho</title>
</head>
<body>
    <input type="text" value="" placeholder="digite">
</body>
</html>

<?php
$livros = [];

function adicionarLivro($titulo, $autor, $quantidade) {
    $livros = ["titulo" => $titulo, "autor" => $autor, "quantidade" => $quantidade];
    $GLOBALS["livros"][] = $livros;
}

function emprestimo($titulo) {
    for ($i = 0; $i < count($GLOBALS["livros"]); $i++) {
        $livros = $GLOBALS["livros"][$i];
        if ($livros["titulo"] == $titulo) {
            $GLOBALS["livros"][$i]["quantidade"] = $livros["quantidade"] - 1;
            if ($GLOBALS["livros"][$i]["quantidade"] < 0) {
                echo "Erro\n";
            }
        }
    }
}

function mostrarLivros(){
    for($i = 0; $i<count($GLOBALS["livros"]); $i++){
        $livros = $GLOBALS["livros"][$i];
        echo "📖 Livro #" . ($i + 1) . "\n";
        echo "Título: " . $livros["titulo"] . "\n";
        echo "Autor: " . $livros["autor"] . "\n";
        echo "Quantidade: " . $livros["quantidade"] . "\n";
        echo"<br/>";
    }
}

#adicionarLivro("PHP Básico", "Fulano", 1);
#adicionarLivro("Roubarammeugato","Deidecosta",1);
#mostrarLivros();
#emprestimo("Roubarammeugato");
#echo "Fim\n";
?>

