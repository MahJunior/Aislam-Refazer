<?php
$servidor = 'localhost:3307';
            $usuario = 'root';
            $senha = '';
            $banco = 'livros';
            $link = mysqli_connect($servidor, $usuario, $senha,$banco) or die('Não foi possível conectar ao banco:');

            $select = mysqli_select_db($link, $banco);
?>